# Results

Measured values from my runs on an NVIDIA Tesla T4 in Google Colab, as CSV files, with charts drawn from those values.

**Inference (notebook 01):** `results_quantization.csv`, `results_kv_cache.csv`, `results_batching.csv`, with `quantization_memory.png`, `kv_cache_growth.png` and `batching_throughput.png`

**Training (notebook 02):** `results_anatomy.csv` with `anatomy_training_step.png`

Results for the seven training setups (`results_training_memory.csv`, `peak_memory_by_technique.png`, `memory_vs_speed.png`, `loss_curves.png`) will be added here.
